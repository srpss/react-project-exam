const Home = require('../models/Home')

exports.lasted3HomesLeaned = () => Home.find().sort({_id: -1}).limit(3);
exports.getAll = () => Home.find();