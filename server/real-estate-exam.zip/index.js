const express = require('express')
const { engine } = require('express-handlebars');
const cookieParser = require('cookie-parser')
const { DbInitialize } = require('./DBConnect');
const { notFound } = require('./middlewares/not-found');
const authService = require('./services/auth');
const { auth, isAuth, isGuest } = require('./middlewares/isAuth');
const homeService = require('./services/home-create');
const homeResultService = require('./services/home');


//Middlewares==========================
const app = express();

app.engine('.hbs', engine({ extname: '.hbs' }));
app.set('view engine', '.hbs');

app.use(cookieParser())

app.use(express.urlencoded({ extended: false }));
app.use(auth)
app.use(express.static('public'));
//HomePage============================
app.get('/', async (req, res) => {

    const homes = await homeResultService.lasted3HomesLeaned().lean();

    res.render('home', { homes });
});
//Login================================
app.get('/login', isGuest, (req, res) => {
    res.render('login');
});

app.post('/login', isGuest, async (req, res) => {

    try {
        const { username, password } = req.body;
        if (username && password) {
            const user = await authService.login(username, password)
            const token = await authService.createToken(user)

            res.cookie('user', token, { httpOnly: true })
            res.redirect('/')
        }
        else {
            const error = 'Username and Password are required'
            return res.render('login', { error: error.message })
        }
    } catch (error) {

        return res.render('login', { error: error.message })
    }


});
//Register=============================
app.get('/register', isGuest, (req, res) => {
    res.render('register');
});
app.post('/register', isGuest, async (req, res) => {
    let { username, password, rePassword, name } = req.body;
    if (username && password && rePassword && name) {
        let data = name.split(' ');

        if (data.length !== 2) {
            return res.render('register', { error: 'Add valid name, example - Martin Slavov' })
        }


        const firstName = data[0]
        const nameCapitalized = firstName.charAt(0).toUpperCase() + firstName.slice(1)
        const lastName = data[1]
        const lastNameCapitalized = lastName.charAt(0).toUpperCase() + lastName.slice(1)

        name = nameCapitalized + " " + lastNameCapitalized

        if (password !== rePassword) {
            return res.render('register', { error: 'Password mismatch' })
        }
        try {
            const createdUser = await authService.create({ username, password, name })
            const token = await authService.createToken(createdUser)
            res.cookie('user', token, { httpOnly: true })

            res.redirect('/');
        } catch (error) {
            return res.render('register', { error: error.message })
        }
    } else {
        return res.render('register', { error: 'All fields are required' })
    }
});
//Logout===============================
app.get('/logout', isAuth, (req, res) => {
    res.clearCookie('user')
    res.redirect('/')
});
//Housing-for-rent=====================
app.get('/housing-for-rent', async (req, res) => {
    const homes = await homeResultService.getAll().lean();
    res.render('housing-for-rent', { homes });
});

//Housing-create=======================
app.get('/housing-create', isAuth, (req, res) => {
    res.render('create');
});

app.post('/housing-create', isAuth, async (req, res) => {
    let data = req.body
    try {

        let check = (data.homeImage.slice(0, 8) != 'https://')
        let check2 = (data.homeImage.slice(0, 7) != 'http://')

        if (check == false && check2 == false) {
            throw { message: "image should start with http:// or https://" }
        }

        data.owner = req.user._id
        await homeService.create(data)
        res.redirect('/housing-for-rent');
    } catch (error) {
        res.render('create', { error: error.message, data });
    }

});

//Search===============================
app.get('/search', isAuth, (req, res) => {
    res.render('search');
});

app.use(notFound)

app.listen(3000, () => console.log('Server started...'))


DbInitialize();

